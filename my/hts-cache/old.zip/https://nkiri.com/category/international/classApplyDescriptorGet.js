<!DOCTYPE html>
<html class="html" lang="en-US">
<head>
	<meta charset="UTF-8">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<meta name='robots' content='noindex, follow' />
<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- This site is optimized with the Yoast SEO plugin v23.5 - https://yoast.com/wordpress/plugins/seo/ -->
	<title>Page not found - Nkiri</title>
	<meta property="og:locale" content="en_US" />
	<meta property="og:title" content="Page not found - Nkiri" />
	<meta property="og:site_name" content="Nkiri" />
	<script type="application/ld+json" class="yoast-schema-graph">{"@context":"https://schema.org","@graph":[{"@type":"WebSite","@id":"https://nkiri.com/#website","url":"https://nkiri.com/","name":"Nkiri","description":"Where movie lovers come","publisher":{"@id":"https://nkiri.com/#organization"},"potentialAction":[{"@type":"SearchAction","target":{"@type":"EntryPoint","urlTemplate":"https://nkiri.com/?s={search_term_string}"},"query-input":{"@type":"PropertyValueSpecification","valueRequired":true,"valueName":"search_term_string"}}],"inLanguage":"en-US"},{"@type":"Organization","@id":"https://nkiri.com/#organization","name":"Nkiri","url":"https://nkiri.com/","logo":{"@type":"ImageObject","inLanguage":"en-US","@id":"https://nkiri.com/#/schema/logo/image/","url":"https://nkiri.com/wp-content/uploads/2019/08/LogoMakr_62nXwA.png","contentUrl":"https://nkiri.com/wp-content/uploads/2019/08/LogoMakr_62nXwA.png","width":400,"height":205,"caption":"Nkiri"},"image":{"@id":"https://nkiri.com/#/schema/logo/image/"}}]}</script>
	<!-- / Yoast SEO plugin. -->


<link rel="alternate" type="application/rss+xml" title="Nkiri &raquo; Feed" href="https://nkiri.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Nkiri &raquo; Comments Feed" href="https://nkiri.com/comments/feed/" />
		<!-- This site uses the Google Analytics by MonsterInsights plugin v9.1.1 - Using Analytics tracking - https://www.monsterinsights.com/ -->
							<script src="//www.googletagmanager.com/gtag/js?id=G-XVP9497M24"  data-cfasync="false" data-wpfc-render="false" async></script>
			<script data-cfasync="false" data-wpfc-render="false">
				var mi_version = '9.1.1';
				var mi_track_user = true;
				var mi_no_track_reason = '';
								var MonsterInsightsDefaultLocations = {"page_location":"https:\/\/nkiri.com\/category\/international\/classApplyDescriptorGet.js\/","page_referrer":"http:\/\/nkiri.com\/wp-content\/themes\/oceanwp\/assets\/js\/theme.min.js?ver=3.6.0"};
				if ( typeof MonsterInsightsPrivacyGuardFilter === 'function' ) {
					var MonsterInsightsLocations = (typeof MonsterInsightsExcludeQuery === 'object') ? MonsterInsightsPrivacyGuardFilter( MonsterInsightsExcludeQuery ) : MonsterInsightsPrivacyGuardFilter( MonsterInsightsDefaultLocations );
				} else {
					var MonsterInsightsLocations = (typeof MonsterInsightsExcludeQuery === 'object') ? MonsterInsightsExcludeQuery : MonsterInsightsDefaultLocations;
				}

								var disableStrs = [
										'ga-disable-G-XVP9497M24',
									];

				/* Function to detect opted out users */
				function __gtagTrackerIsOptedOut() {
					for (var index = 0; index < disableStrs.length; index++) {
						if (document.cookie.indexOf(disableStrs[index] + '=true') > -1) {
							return true;
						}
					}

					return false;
				}

				/* Disable tracking if the opt-out cookie exists. */
				if (__gtagTrackerIsOptedOut()) {
					for (var index = 0; index < disableStrs.length; index++) {
						window[disableStrs[index]] = true;
					}
				}

				/* Opt-out function */
				function __gtagTrackerOptout() {
					for (var index = 0; index < disableStrs.length; index++) {
						document.cookie = disableStrs[index] + '=true; expires=Thu, 31 Dec 2099 23:59:59 UTC; path=/';
						window[disableStrs[index]] = true;
					}
				}

				if ('undefined' === typeof gaOptout) {
					function gaOptout() {
						__gtagTrackerOptout();
					}
				}
								window.dataLayer = window.dataLayer || [];

				window.MonsterInsightsDualTracker = {
					helpers: {},
					trackers: {},
				};
				if (mi_track_user) {
					function __gtagDataLayer() {
						dataLayer.push(arguments);
					}

					function __gtagTracker(type, name, parameters) {
						if (!parameters) {
							parameters = {};
						}

						if (parameters.send_to) {
							__gtagDataLayer.apply(null, arguments);
							return;
						}

						if (type === 'event') {
														parameters.send_to = monsterinsights_frontend.v4_id;
							var hookName = name;
							if (typeof parameters['event_category'] !== 'undefined') {
								hookName = parameters['event_category'] + ':' + name;
							}

							if (typeof MonsterInsightsDualTracker.trackers[hookName] !== 'undefined') {
								MonsterInsightsDualTracker.trackers[hookName](parameters);
							} else {
								__gtagDataLayer('event', name, parameters);
							}
							
						} else {
							__gtagDataLayer.apply(null, arguments);
						}
					}

					__gtagTracker('js', new Date());
					__gtagTracker('set', {
						'developer_id.dZGIzZG': true,
											});
					if ( MonsterInsightsLocations.page_location ) {
						__gtagTracker('set', MonsterInsightsLocations);
					}
										__gtagTracker('config', 'G-XVP9497M24', {"forceSSL":"true","link_attribution":"true","page_path":'\/404.html?page=' + document.location.pathname + document.location.search + '&from=' + document.referrer} );
															window.gtag = __gtagTracker;										(function () {
						/* https://developers.google.com/analytics/devguides/collection/analyticsjs/ */
						/* ga and __gaTracker compatibility shim. */
						var noopfn = function () {
							return null;
						};
						var newtracker = function () {
							return new Tracker();
						};
						var Tracker = function () {
							return null;
						};
						var p = Tracker.prototype;
						p.get = noopfn;
						p.set = noopfn;
						p.send = function () {
							var args = Array.prototype.slice.call(arguments);
							args.unshift('send');
							__gaTracker.apply(null, args);
						};
						var __gaTracker = function () {
							var len = arguments.length;
							if (len === 0) {
								return;
							}
							var f = arguments[len - 1];
							if (typeof f !== 'object' || f === null || typeof f.hitCallback !== 'function') {
								if ('send' === arguments[0]) {
									var hitConverted, hitObject = false, action;
									if ('event' === arguments[1]) {
										if ('undefined' !== typeof arguments[3]) {
											hitObject = {
												'eventAction': arguments[3],
												'eventCategory': arguments[2],
												'eventLabel': arguments[4],
												'value': arguments[5] ? arguments[5] : 1,
											}
										}
									}
									if ('pageview' === arguments[1]) {
										if ('undefined' !== typeof arguments[2]) {
											hitObject = {
												'eventAction': 'page_view',
												'page_path': arguments[2],
											}
										}
									}
									if (typeof arguments[2] === 'object') {
										hitObject = arguments[2];
									}
									if (typeof arguments[5] === 'object') {
										Object.assign(hitObject, arguments[5]);
									}
									if ('undefined' !== typeof arguments[1].hitType) {
										hitObject = arguments[1];
										if ('pageview' === hitObject.hitType) {
											hitObject.eventAction = 'page_view';
										}
									}
									if (hitObject) {
										action = 'timing' === arguments[1].hitType ? 'timing_complete' : hitObject.eventAction;
										hitConverted = mapArgs(hitObject);
										__gtagTracker('event', action, hitConverted);
									}
								}
								return;
							}

							function mapArgs(args) {
								var arg, hit = {};
								var gaMap = {
									'eventCategory': 'event_category',
									'eventAction': 'event_action',
									'eventLabel': 'event_label',
									'eventValue': 'event_value',
									'nonInteraction': 'non_interaction',
									'timingCategory': 'event_category',
									'timingVar': 'name',
									'timingValue': 'value',
									'timingLabel': 'event_label',
									'page': 'page_path',
									'location': 'page_location',
									'title': 'page_title',
									'referrer' : 'page_referrer',
								};
								for (arg in args) {
																		if (!(!args.hasOwnProperty(arg) || !gaMap.hasOwnProperty(arg))) {
										hit[gaMap[arg]] = args[arg];
									} else {
										hit[arg] = args[arg];
									}
								}
								return hit;
							}

							try {
								f.hitCallback();
							} catch (ex) {
							}
						};
						__gaTracker.create = newtracker;
						__gaTracker.getByName = newtracker;
						__gaTracker.getAll = function () {
							return [];
						};
						__gaTracker.remove = noopfn;
						__gaTracker.loaded = true;
						window['__gaTracker'] = __gaTracker;
					})();
									} else {
										console.log("");
					(function () {
						function __gtagTracker() {
							return null;
						}

						window['__gtagTracker'] = __gtagTracker;
						window['gtag'] = __gtagTracker;
					})();
									}
			</script>
				<!-- / Google Analytics by MonsterInsights -->
		<script>
window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/15.0.3\/svg\/","svgExt":".svg","source":{"wpemoji":"https:\/\/nkiri.com\/wp-includes\/js\/wp-emoji.js?ver=6.6.2","twemoji":"https:\/\/nkiri.com\/wp-includes\/js\/twemoji.js?ver=6.6.2"}};
/**
 * @output wp-includes/js/wp-emoji-loader.js
 */

/**
 * Emoji Settings as exported in PHP via _print_emoji_detection_script().
 * @typedef WPEmojiSettings
 * @type {object}
 * @property {?object} source
 * @property {?string} source.concatemoji
 * @property {?string} source.twemoji
 * @property {?string} source.wpemoji
 * @property {?boolean} DOMReady
 * @property {?Function} readyCallback
 */

/**
 * Support tests.
 * @typedef SupportTests
 * @type {object}
 * @property {?boolean} flag
 * @property {?boolean} emoji
 */

/**
 * IIFE to detect emoji support and load Twemoji if needed.
 *
 * @param {Window} window
 * @param {Document} document
 * @param {WPEmojiSettings} settings
 */
( function wpEmojiLoader( window, document, settings ) {
	if ( typeof Promise === 'undefined' ) {
		return;
	}

	var sessionStorageKey = 'wpEmojiSettingsSupports';
	var tests = [ 'flag', 'emoji' ];

	/**
	 * Checks whether the browser supports offloading to a Worker.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @returns {boolean}
	 */
	function supportsWorkerOffloading() {
		return (
			typeof Worker !== 'undefined' &&
			typeof OffscreenCanvas !== 'undefined' &&
			typeof URL !== 'undefined' &&
			URL.createObjectURL &&
			typeof Blob !== 'undefined'
		);
	}

	/**
	 * @typedef SessionSupportTests
	 * @type {object}
	 * @property {number} timestamp
	 * @property {SupportTests} supportTests
	 */

	/**
	 * Get support tests from session.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @returns {?SupportTests} Support tests, or null if not set or older than 1 week.
	 */
	function getSessionSupportTests() {
		try {
			/** @type {SessionSupportTests} */
			var item = JSON.parse(
				sessionStorage.getItem( sessionStorageKey )
			);
			if (
				typeof item === 'object' &&
				typeof item.timestamp === 'number' &&
				new Date().valueOf() < item.timestamp + 604800 && // Note: Number is a week in seconds.
				typeof item.supportTests === 'object'
			) {
				return item.supportTests;
			}
		} catch ( e ) {}
		return null;
	}

	/**
	 * Persist the supports in session storage.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @param {SupportTests} supportTests Support tests.
	 */
	function setSessionSupportTests( supportTests ) {
		try {
			/** @type {SessionSupportTests} */
			var item = {
				supportTests: supportTests,
				timestamp: new Date().valueOf()
			};

			sessionStorage.setItem(
				sessionStorageKey,
				JSON.stringify( item )
			);
		} catch ( e ) {}
	}

	/**
	 * Checks if two sets of Emoji characters render the same visually.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 4.9.0
	 *
	 * @private
	 *
	 * @param {CanvasRenderingContext2D} context 2D Context.
	 * @param {string} set1 Set of Emoji to test.
	 * @param {string} set2 Set of Emoji to test.
	 *
	 * @return {boolean} True if the two sets render the same.
	 */
	function emojiSetsRenderIdentically( context, set1, set2 ) {
		// Cleanup from previous test.
		context.clearRect( 0, 0, context.canvas.width, context.canvas.height );
		context.fillText( set1, 0, 0 );
		var rendered1 = new Uint32Array(
			context.getImageData(
				0,
				0,
				context.canvas.width,
				context.canvas.height
			).data
		);

		// Cleanup from previous test.
		context.clearRect( 0, 0, context.canvas.width, context.canvas.height );
		context.fillText( set2, 0, 0 );
		var rendered2 = new Uint32Array(
			context.getImageData(
				0,
				0,
				context.canvas.width,
				context.canvas.height
			).data
		);

		return rendered1.every( function ( rendered2Data, index ) {
			return rendered2Data === rendered2[ index ];
		} );
	}

	/**
	 * Determines if the browser properly renders Emoji that Twemoji can supplement.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 4.2.0
	 *
	 * @private
	 *
	 * @param {CanvasRenderingContext2D} context 2D Context.
	 * @param {string} type Whether to test for support of "flag" or "emoji".
	 * @param {Function} emojiSetsRenderIdentically Reference to emojiSetsRenderIdentically function, needed due to minification.
	 *
	 * @return {boolean} True if the browser can render emoji, false if it cannot.
	 */
	function browserSupportsEmoji( context, type, emojiSetsRenderIdentically ) {
		var isIdentical;

		switch ( type ) {
			case 'flag':
				/*
				 * Test for Transgender flag compatibility. Added in Unicode 13.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly (white flag emoji + transgender symbol).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83C\uDFF3\uFE0F\u200D\u26A7\uFE0F', // as a zero-width joiner sequence
					'\uD83C\uDFF3\uFE0F\u200B\u26A7\uFE0F' // separated by a zero-width space
				);

				if ( isIdentical ) {
					return false;
				}

				/*
				 * Test for UN flag compatibility. This is the least supported of the letter locale flags,
				 * so gives us an easy test for full support.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly ([U] + [N]).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83C\uDDFA\uD83C\uDDF3', // as the sequence of two code points
					'\uD83C\uDDFA\u200B\uD83C\uDDF3' // as the two code points separated by a zero-width space
				);

				if ( isIdentical ) {
					return false;
				}

				/*
				 * Test for English flag compatibility. England is a country in the United Kingdom, it
				 * does not have a two letter locale code but rather a five letter sub-division code.
				 *
				 * To test for support, we try to render it, and compare the rendering to how it would look if
				 * the browser doesn't render it correctly (black flag emoji + [G] + [B] + [E] + [N] + [G]).
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					// as the flag sequence
					'\uD83C\uDFF4\uDB40\uDC67\uDB40\uDC62\uDB40\uDC65\uDB40\uDC6E\uDB40\uDC67\uDB40\uDC7F',
					// with each code point separated by a zero-width space
					'\uD83C\uDFF4\u200B\uDB40\uDC67\u200B\uDB40\uDC62\u200B\uDB40\uDC65\u200B\uDB40\uDC6E\u200B\uDB40\uDC67\u200B\uDB40\uDC7F'
				);

				return ! isIdentical;
			case 'emoji':
				/*
				 * Four and twenty blackbirds baked in a pie.
				 *
				 * To test for Emoji 15.0 support, try to render a new emoji: Blackbird.
				 *
				 * The Blackbird is a ZWJ sequence combining 🐦 Bird and ⬛ large black square.,
				 *
				 * 0x1F426 (\uD83D\uDC26) == Bird
				 * 0x200D == Zero-Width Joiner (ZWJ) that links the code points for the new emoji or
				 * 0x200B == Zero-Width Space (ZWS) that is rendered for clients not supporting the new emoji.
				 * 0x2B1B == Large Black Square
				 *
				 * When updating this test for future Emoji releases, ensure that individual emoji that make up the
				 * sequence come from older emoji standards.
				 */
				isIdentical = emojiSetsRenderIdentically(
					context,
					'\uD83D\uDC26\u200D\u2B1B', // as the zero-width joiner sequence
					'\uD83D\uDC26\u200B\u2B1B' // separated by a zero-width space
				);

				return ! isIdentical;
		}

		return false;
	}

	/**
	 * Checks emoji support tests.
	 *
	 * This function may be serialized to run in a Worker. Therefore, it cannot refer to variables from the containing
	 * scope. Everything must be passed by parameters.
	 *
	 * @since 6.3.0
	 *
	 * @private
	 *
	 * @param {string[]} tests Tests.
	 * @param {Function} browserSupportsEmoji Reference to browserSupportsEmoji function, needed due to minification.
	 * @param {Function} emojiSetsRenderIdentically Reference to emojiSetsRenderIdentically function, needed due to minification.
	 *
	 * @return {SupportTests} Support tests.
	 */
	function testEmojiSupports( tests, browserSupportsEmoji, emojiSetsRenderIdentically ) {
		var canvas;
		if (
			typeof WorkerGlobalScope !== 'undefined' &&
			self instanceof WorkerGlobalScope
		) {
			canvas = new OffscreenCanvas( 300, 150 ); // Dimensions are default for HTMLCanvasElement.
		} else {
			canvas = document.createElement( 'canvas' );
		}

		var context = canvas.getContext( '2d', { willReadFrequently: true } );

		/*
		 * Chrome on OS X added native emoji rendering in M41. Unfortunately,
		 * it doesn't work when the font is bolder than 500 weight. So, we
		 * check for bold rendering support to avoid invisible emoji in Chrome.
		 */
		context.textBaseline = 'top';
		context.font = '600 32px Arial';

		var supports = {};
		tests.forEach( function ( test ) {
			supports[ test ] = browserSupportsEmoji( context, test, emojiSetsRenderIdentically );
		} );
		return supports;
	}

	/**
	 * Adds a script to the head of the document.
	 *
	 * @ignore
	 *
	 * @since 4.2.0
	 *
	 * @param {string} src The url where the script is located.
	 *
	 * @return {void}
	 */
	function addScript( src ) {
		var script = document.createElement( 'script' );
		script.src = src;
		script.defer = true;
		document.head.appendChild( script );
	}

	settings.supports = {
		everything: true,
		everythingExceptFlag: true
	};

	// Create a promise for DOMContentLoaded since the worker logic may finish after the event has fired.
	var domReadyPromise = new Promise( function ( resolve ) {
		document.addEventListener( 'DOMContentLoaded', resolve, {
			once: true
		} );
	} );

	// Obtain the emoji support from the browser, asynchronously when possible.
	new Promise( function ( resolve ) {
		var supportTests = getSessionSupportTests();
		if ( supportTests ) {
			resolve( supportTests );
			return;
		}

		if ( supportsWorkerOffloading() ) {
			try {
				// Note that the functions are being passed as arguments due to minification.
				var workerScript =
					'postMessage(' +
					testEmojiSupports.toString() +
					'(' +
					[
						JSON.stringify( tests ),
						browserSupportsEmoji.toString(),
						emojiSetsRenderIdentically.toString()
					].join( ',' ) +
					'));';
				var blob = new Blob( [ workerScript ], {
					type: 'text/javascript'
				} );
				var worker = new Worker( URL.createObjectURL( blob ), { name: 'wpTestEmojiSupports' } );
				worker.onmessage = function ( event ) {
					supportTests = event.data;
					setSessionSupportTests( supportTests );
					worker.terminate();
					resolve( supportTests );
				};
				return;
			} catch ( e ) {}
		}

		supportTests = testEmojiSupports( tests, browserSupportsEmoji, emojiSetsRenderIdentically );
		setSessionSupportTests( supportTests );
		resolve( supportTests );
	} )
		// Once the browser emoji support has been obtained from the session, finalize the settings.
		.then( function ( supportTests ) {
			/*
			 * Tests the browser support for flag emojis and other emojis, and adjusts the
			 * support settings accordingly.
			 */
			for ( var test in supportTests ) {
				settings.supports[ test ] = supportTests[ test ];

				settings.supports.everything =
					settings.supports.everything && settings.supports[ test ];

				if ( 'flag' !== test ) {
					settings.supports.everythingExceptFlag =
						settings.supports.everythingExceptFlag &&
						settings.supports[ test ];
				}
			}

			settings.supports.everythingExceptFlag =
				settings.supports.everythingExceptFlag &&
				! settings.supports.flag;

			// Sets DOMReady to false and assigns a ready function to settings.
			settings.DOMReady = false;
			settings.readyCallback = function () {
				settings.DOMReady = true;
			};
		} )
		.then( function () {
			return domReadyPromise;
		} )
		.then( function () {
			// When the browser can not render everything we need to load a polyfill.
			if ( ! settings.supports.everything ) {
				settings.readyCallback();

				var src = settings.source || {};

				if ( src.concatemoji ) {
					addScript( src.concatemoji );
				} else if ( src.wpemoji && src.twemoji ) {
					addScript( src.twemoji );
					addScript( src.wpemoji );
				}
			}
		} );
} )( window, document, window._wpemojiSettings );
</script>
<!-- nkiri.com is managing ads with Advanced Ads 1.54.1 --><script id="nkiri-ready">
			/**
 * Wait for the page to be ready before firing JS.
 *
 * @param {function} callback - A callable function to be executed.
 * @param {string} [requestedState=complete] - document.readyState to wait for. Defaults to 'complete', can be 'interactive'.
 */
window.advanced_ads_ready = function ( callback, requestedState ) {
	requestedState = requestedState || 'complete';
	var checkState = function ( state ) {
		return requestedState === 'interactive' ? state !== 'loading' : state === 'complete';
	};

	// If we have reached the correct state, fire the callback.
	if ( checkState( document.readyState ) ) {
		callback();
		return;
	}
	// We are not yet in the correct state, attach an event handler, only fire once if the requested state is 'interactive'.
	document.addEventListener( 'readystatechange', function ( event ) {
		if ( checkState( event.target.readyState ) ) {
			callback();
		}
	}, {once: requestedState === 'interactive'} );
};

window.advanced_ads_ready_queue = window.advanced_ads_ready_queue || [];
		</script>
		<style id='wp-emoji-styles-inline-css'>

	img.wp-smiley, img.emoji {
		display: inline !important;
		border: none !important;
		box-shadow: none !important;
		height: 1em !important;
		width: 1em !important;
		margin: 0 0.07em !important;
		vertical-align: -0.1em !important;
		background: none !important;
		padding: 0 !important;
	}
</style>
<link rel='stylesheet' id='wp-block-library-css' href='https://nkiri.com/wp-includes/css/dist/block-library/style.css?ver=6.6.2' media='all' />
<style id='wp-block-library-theme-inline-css'>
.wp-block-audio :where(figcaption){
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme .wp-block-audio :where(figcaption){
  color:#ffffffa6;
}

.wp-block-audio{
  margin:0 0 1em;
}

.wp-block-code{
  border:1px solid #ccc;
  border-radius:4px;
  font-family:Menlo,Consolas,monaco,monospace;
  padding:.8em 1em;
}

.wp-block-embed :where(figcaption){
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme .wp-block-embed :where(figcaption){
  color:#ffffffa6;
}

.wp-block-embed{
  margin:0 0 1em;
}

.blocks-gallery-caption{
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme .blocks-gallery-caption{
  color:#ffffffa6;
}

:root :where(.wp-block-image figcaption){
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme :root :where(.wp-block-image figcaption){
  color:#ffffffa6;
}

.wp-block-image{
  margin:0 0 1em;
}

.wp-block-pullquote{
  border-bottom:4px solid;
  border-top:4px solid;
  color:currentColor;
  margin-bottom:1.75em;
}
.wp-block-pullquote cite,.wp-block-pullquote footer,.wp-block-pullquote__citation{
  color:currentColor;
  font-size:.8125em;
  font-style:normal;
  text-transform:uppercase;
}

.wp-block-quote{
  border-left:.25em solid;
  margin:0 0 1.75em;
  padding-left:1em;
}
.wp-block-quote cite,.wp-block-quote footer{
  color:currentColor;
  font-size:.8125em;
  font-style:normal;
  position:relative;
}
.wp-block-quote.has-text-align-right{
  border-left:none;
  border-right:.25em solid;
  padding-left:0;
  padding-right:1em;
}
.wp-block-quote.has-text-align-center{
  border:none;
  padding-left:0;
}
.wp-block-quote.is-large,.wp-block-quote.is-style-large,.wp-block-quote.is-style-plain{
  border:none;
}

.wp-block-search .wp-block-search__label{
  font-weight:700;
}

.wp-block-search__button{
  border:1px solid #ccc;
  padding:.375em .625em;
}

:where(.wp-block-group.has-background){
  padding:1.25em 2.375em;
}

.wp-block-separator.has-css-opacity{
  opacity:.4;
}

.wp-block-separator{
  border:none;
  border-bottom:2px solid;
  margin-left:auto;
  margin-right:auto;
}
.wp-block-separator.has-alpha-channel-opacity{
  opacity:1;
}
.wp-block-separator:not(.is-style-wide):not(.is-style-dots){
  width:100px;
}
.wp-block-separator.has-background:not(.is-style-dots){
  border-bottom:none;
  height:1px;
}
.wp-block-separator.has-background:not(.is-style-wide):not(.is-style-dots){
  height:2px;
}

.wp-block-table{
  margin:0 0 1em;
}
.wp-block-table td,.wp-block-table th{
  word-break:normal;
}
.wp-block-table :where(figcaption){
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme .wp-block-table :where(figcaption){
  color:#ffffffa6;
}

.wp-block-video :where(figcaption){
  color:#555;
  font-size:13px;
  text-align:center;
}
.is-dark-theme .wp-block-video :where(figcaption){
  color:#ffffffa6;
}

.wp-block-video{
  margin:0 0 1em;
}

:root :where(.wp-block-template-part.has-background){
  margin-bottom:0;
  margin-top:0;
  padding:1.25em 2.375em;
}
</style>
<style id='classic-theme-styles-inline-css'>
/**
 * These rules are needed for backwards compatibility.
 * They should match the button element rules in the base theme.json file.
 */
.wp-block-button__link {
	color: #ffffff;
	background-color: #32373c;
	border-radius: 9999px; /* 100% causes an oval, but any explicit but really high value retains the pill shape. */

	/* This needs a low specificity so it won't override the rules from the button element if defined in theme.json. */
	box-shadow: none;
	text-decoration: none;

	/* The extra 2px are added to size solids the same as the outline versions.*/
	padding: calc(0.667em + 2px) calc(1.333em + 2px);

	font-size: 1.125em;
}

.wp-block-file__button {
	background: #32373c;
	color: #ffffff;
	text-decoration: none;
}

</style>
<style id='global-styles-inline-css'>
:root{--wp--preset--aspect-ratio--square: 1;--wp--preset--aspect-ratio--4-3: 4/3;--wp--preset--aspect-ratio--3-4: 3/4;--wp--preset--aspect-ratio--3-2: 3/2;--wp--preset--aspect-ratio--2-3: 2/3;--wp--preset--aspect-ratio--16-9: 16/9;--wp--preset--aspect-ratio--9-16: 9/16;--wp--preset--color--black: #000000;--wp--preset--color--cyan-bluish-gray: #abb8c3;--wp--preset--color--white: #ffffff;--wp--preset--color--pale-pink: #f78da7;--wp--preset--color--vivid-red: #cf2e2e;--wp--preset--color--luminous-vivid-orange: #ff6900;--wp--preset--color--luminous-vivid-amber: #fcb900;--wp--preset--color--light-green-cyan: #7bdcb5;--wp--preset--color--vivid-green-cyan: #00d084;--wp--preset--color--pale-cyan-blue: #8ed1fc;--wp--preset--color--vivid-cyan-blue: #0693e3;--wp--preset--color--vivid-purple: #9b51e0;--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple: linear-gradient(135deg,rgba(6,147,227,1) 0%,rgb(155,81,224) 100%);--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan: linear-gradient(135deg,rgb(122,220,180) 0%,rgb(0,208,130) 100%);--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange: linear-gradient(135deg,rgba(252,185,0,1) 0%,rgba(255,105,0,1) 100%);--wp--preset--gradient--luminous-vivid-orange-to-vivid-red: linear-gradient(135deg,rgba(255,105,0,1) 0%,rgb(207,46,46) 100%);--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray: linear-gradient(135deg,rgb(238,238,238) 0%,rgb(169,184,195) 100%);--wp--preset--gradient--cool-to-warm-spectrum: linear-gradient(135deg,rgb(74,234,220) 0%,rgb(151,120,209) 20%,rgb(207,42,186) 40%,rgb(238,44,130) 60%,rgb(251,105,98) 80%,rgb(254,248,76) 100%);--wp--preset--gradient--blush-light-purple: linear-gradient(135deg,rgb(255,206,236) 0%,rgb(152,150,240) 100%);--wp--preset--gradient--blush-bordeaux: linear-gradient(135deg,rgb(254,205,165) 0%,rgb(254,45,45) 50%,rgb(107,0,62) 100%);--wp--preset--gradient--luminous-dusk: linear-gradient(135deg,rgb(255,203,112) 0%,rgb(199,81,192) 50%,rgb(65,88,208) 100%);--wp--preset--gradient--pale-ocean: linear-gradient(135deg,rgb(255,245,203) 0%,rgb(182,227,212) 50%,rgb(51,167,181) 100%);--wp--preset--gradient--electric-grass: linear-gradient(135deg,rgb(202,248,128) 0%,rgb(113,206,126) 100%);--wp--preset--gradient--midnight: linear-gradient(135deg,rgb(2,3,129) 0%,rgb(40,116,252) 100%);--wp--preset--font-size--small: 13px;--wp--preset--font-size--medium: 20px;--wp--preset--font-size--large: 36px;--wp--preset--font-size--x-large: 42px;--wp--preset--spacing--20: 0.44rem;--wp--preset--spacing--30: 0.67rem;--wp--preset--spacing--40: 1rem;--wp--preset--spacing--50: 1.5rem;--wp--preset--spacing--60: 2.25rem;--wp--preset--spacing--70: 3.38rem;--wp--preset--spacing--80: 5.06rem;--wp--preset--shadow--natural: 6px 6px 9px rgba(0, 0, 0, 0.2);--wp--preset--shadow--deep: 12px 12px 50px rgba(0, 0, 0, 0.4);--wp--preset--shadow--sharp: 6px 6px 0px rgba(0, 0, 0, 0.2);--wp--preset--shadow--outlined: 6px 6px 0px -3px rgba(255, 255, 255, 1), 6px 6px rgba(0, 0, 0, 1);--wp--preset--shadow--crisp: 6px 6px 0px rgba(0, 0, 0, 1);}:where(.is-layout-flex){gap: 0.5em;}:where(.is-layout-grid){gap: 0.5em;}body .is-layout-flex{display: flex;}.is-layout-flex{flex-wrap: wrap;align-items: center;}.is-layout-flex > :is(*, div){margin: 0;}body .is-layout-grid{display: grid;}.is-layout-grid > :is(*, div){margin: 0;}:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}.has-black-color{color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-color{color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-color{color: var(--wp--preset--color--white) !important;}.has-pale-pink-color{color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-color{color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-color{color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-color{color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-color{color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-color{color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-color{color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-color{color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-color{color: var(--wp--preset--color--vivid-purple) !important;}.has-black-background-color{background-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-background-color{background-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-background-color{background-color: var(--wp--preset--color--white) !important;}.has-pale-pink-background-color{background-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-background-color{background-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-background-color{background-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-background-color{background-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-background-color{background-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-background-color{background-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-background-color{background-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-background-color{background-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-background-color{background-color: var(--wp--preset--color--vivid-purple) !important;}.has-black-border-color{border-color: var(--wp--preset--color--black) !important;}.has-cyan-bluish-gray-border-color{border-color: var(--wp--preset--color--cyan-bluish-gray) !important;}.has-white-border-color{border-color: var(--wp--preset--color--white) !important;}.has-pale-pink-border-color{border-color: var(--wp--preset--color--pale-pink) !important;}.has-vivid-red-border-color{border-color: var(--wp--preset--color--vivid-red) !important;}.has-luminous-vivid-orange-border-color{border-color: var(--wp--preset--color--luminous-vivid-orange) !important;}.has-luminous-vivid-amber-border-color{border-color: var(--wp--preset--color--luminous-vivid-amber) !important;}.has-light-green-cyan-border-color{border-color: var(--wp--preset--color--light-green-cyan) !important;}.has-vivid-green-cyan-border-color{border-color: var(--wp--preset--color--vivid-green-cyan) !important;}.has-pale-cyan-blue-border-color{border-color: var(--wp--preset--color--pale-cyan-blue) !important;}.has-vivid-cyan-blue-border-color{border-color: var(--wp--preset--color--vivid-cyan-blue) !important;}.has-vivid-purple-border-color{border-color: var(--wp--preset--color--vivid-purple) !important;}.has-vivid-cyan-blue-to-vivid-purple-gradient-background{background: var(--wp--preset--gradient--vivid-cyan-blue-to-vivid-purple) !important;}.has-light-green-cyan-to-vivid-green-cyan-gradient-background{background: var(--wp--preset--gradient--light-green-cyan-to-vivid-green-cyan) !important;}.has-luminous-vivid-amber-to-luminous-vivid-orange-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-amber-to-luminous-vivid-orange) !important;}.has-luminous-vivid-orange-to-vivid-red-gradient-background{background: var(--wp--preset--gradient--luminous-vivid-orange-to-vivid-red) !important;}.has-very-light-gray-to-cyan-bluish-gray-gradient-background{background: var(--wp--preset--gradient--very-light-gray-to-cyan-bluish-gray) !important;}.has-cool-to-warm-spectrum-gradient-background{background: var(--wp--preset--gradient--cool-to-warm-spectrum) !important;}.has-blush-light-purple-gradient-background{background: var(--wp--preset--gradient--blush-light-purple) !important;}.has-blush-bordeaux-gradient-background{background: var(--wp--preset--gradient--blush-bordeaux) !important;}.has-luminous-dusk-gradient-background{background: var(--wp--preset--gradient--luminous-dusk) !important;}.has-pale-ocean-gradient-background{background: var(--wp--preset--gradient--pale-ocean) !important;}.has-electric-grass-gradient-background{background: var(--wp--preset--gradient--electric-grass) !important;}.has-midnight-gradient-background{background: var(--wp--preset--gradient--midnight) !important;}.has-small-font-size{font-size: var(--wp--preset--font-size--small) !important;}.has-medium-font-size{font-size: var(--wp--preset--font-size--medium) !important;}.has-large-font-size{font-size: var(--wp--preset--font-size--large) !important;}.has-x-large-font-size{font-size: var(--wp--preset--font-size--x-large) !important;}
:where(.wp-block-post-template.is-layout-flex){gap: 1.25em;}:where(.wp-block-post-template.is-layout-grid){gap: 1.25em;}
:where(.wp-block-columns.is-layout-flex){gap: 2em;}:where(.wp-block-columns.is-layout-grid){gap: 2em;}
:root :where(.wp-block-pullquote){font-size: 1.5em;line-height: 1.6;}
</style>
<link rel='stylesheet' id='ivory-search-styles-css' href='https://nkiri.com/wp-content/plugins/add-search-to-menu/public/css/ivory-search.min.css?ver=5.5.7' media='all' />
<link rel='stylesheet' id='font-awesome-css' href='https://nkiri.com/wp-content/themes/oceanwp/assets/fonts/fontawesome/css/all.min.css?ver=3.6.0' media='all' />
<link rel='stylesheet' id='simple-line-icons-css' href='https://nkiri.com/wp-content/themes/oceanwp/assets/css/third/simple-line-icons.min.css?ver=3.6.0' media='all' />
<link rel='stylesheet' id='oceanwp-style-css' href='https://nkiri.com/wp-content/themes/oceanwp/assets/css/style.min.css?ver=3.6.0' media='all' />
<link rel='stylesheet' id='elementor-frontend-css' href='https://nkiri.com/wp-content/plugins/elementor/assets/css/frontend.css?ver=3.24.5' media='all' />
<link rel='stylesheet' id='eael-general-css' href='https://nkiri.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/css/view/general.min.css?ver=6.0.6' media='all' />
<script src="https://nkiri.com/wp-content/plugins/google-analytics-for-wordpress/assets/js/frontend-gtag.js?ver=1728386474" id="monsterinsights-frontend-script-js" async data-wp-strategy="async"></script>
<script data-cfasync="false" data-wpfc-render="false" id='monsterinsights-frontend-script-js-extra'>var monsterinsights_frontend = {"js_events_tracking":"true","download_extensions":"mkv,mp4,docx,pptx,xlsx","inbound_paths":"[{\"path\":\"\\\/go\\\/\",\"label\":\"affiliate\"},{\"path\":\"\\\/recommend\\\/\",\"label\":\"affiliate\"}]","home_url":"https:\/\/nkiri.com","hash_tracking":"false","v4_id":"G-XVP9497M24"};</script>
<script src="https://nkiri.com/wp-includes/js/jquery/jquery.js?ver=3.7.1" id="jquery-core-js"></script>
<script src="https://nkiri.com/wp-includes/js/jquery/jquery-migrate.js?ver=3.4.1" id="jquery-migrate-js"></script>
<link rel="https://api.w.org/" href="https://nkiri.com/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://nkiri.com/xmlrpc.php?rsd" />
<meta name="generator" content="WordPress 6.6.2" />
<meta name="generator" content="Elementor 3.24.5; features: additional_custom_breakpoints; settings: css_print_method-external, google_font-enabled, font_display-auto">
			<style>
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload),
				.e-con.e-parent:nth-of-type(n+4):not(.e-lazyloaded):not(.e-no-lazyload) * {
					background-image: none !important;
				}
				@media screen and (max-height: 1024px) {
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+3):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
				@media screen and (max-height: 640px) {
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload),
					.e-con.e-parent:nth-of-type(n+2):not(.e-lazyloaded):not(.e-no-lazyload) * {
						background-image: none !important;
					}
				}
			</style>
			<link rel="icon" href="https://nkiri.com/wp-content/uploads/2019/08/cropped-LogoMakr_62nXwA-32x32.png" sizes="32x32" />
<link rel="icon" href="https://nkiri.com/wp-content/uploads/2019/08/cropped-LogoMakr_62nXwA-192x192.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://nkiri.com/wp-content/uploads/2019/08/cropped-LogoMakr_62nXwA-180x180.png" />
<meta name="msapplication-TileImage" content="https://nkiri.com/wp-content/uploads/2019/08/cropped-LogoMakr_62nXwA-270x270.png" />
<!-- OceanWP CSS -->
<style type="text/css">
/* Header CSS */#site-header.has-header-media .overlay-header-media{background-color:rgba(0,0,0,0.5)}#site-logo #site-logo-inner a img,#site-header.center-header #site-navigation-wrap .middle-site-logo a img{max-width:108px}
</style>			<style type="text/css">
					</style>
		
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
.alert {
  padding: 20px;
  background-color: #f44336;
  color: white;
}

.closebtn {
  margin-left: 15px;
  color: white;
  font-weight: bold;
  float: right;
  font-size: 22px;
  line-height: 20px;
  cursor: pointer;
  transition: 0.3s;
}

.closebtn:hover {
  color: black;
}
</style>
</head>
<body>
<div class="alert">
  <span class="closebtn" onclick="this.parentElement.style.display='none';">&times;</span> 
  <strong>Beware of fake sites and social media accounts.</strong> Our only domain is <strong> NKIRI.COM.</strong>
</div>

</body>
</head>

<body class="error404 wp-custom-logo wp-embed-responsive oceanwp oceanwp-theme dropdown-mobile default-breakpoint content-full-width content-max-width page-header-disabled has-breadcrumbs elementor-default elementor-kit-7653 aa-prefix-nkiri-" itemscope="itemscope" itemtype="https://schema.org/WebPage">

	
	
	<div id="outer-wrap" class="site clr">

		<a class="skip-link screen-reader-text" href="#main">Skip to content</a>

		
		<div id="wrap" class="clr">

			
			
<header id="site-header" class="minimal-header has-social clr" data-height="74" itemscope="itemscope" itemtype="https://schema.org/WPHeader" role="banner">

	
					
			<div id="site-header-inner" class="clr container">

				
				

<div id="site-logo" class="clr" itemscope itemtype="https://schema.org/Brand" >

	
	<div id="site-logo-inner" class="clr">

		<a href="https://nkiri.com/" class="custom-logo-link" rel="home"><img fetchpriority="high" width="400" height="205" src="https://nkiri.com/wp-content/uploads/2019/08/cropped-cropped-cropped-cropped-cropped-LogoMakr_62nXwA-1.png" class="custom-logo" alt="Nkiri" decoding="async" srcset="https://nkiri.com/wp-content/uploads/2019/08/cropped-cropped-cropped-cropped-cropped-LogoMakr_62nXwA-1.png 400w, https://nkiri.com/wp-content/uploads/2019/08/cropped-cropped-cropped-cropped-cropped-LogoMakr_62nXwA-1-300x154.png 300w" sizes="(max-width: 400px) 100vw, 400px" /></a>
	</div><!-- #site-logo-inner -->

	
	
</div><!-- #site-logo -->

			<div id="site-navigation-wrap" class="clr">
			
			
			
			<nav id="site-navigation" class="navigation main-navigation clr" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement" role="navigation" >

				<ul id="menu-main-menu" class="main-menu dropdown-menu sf-menu"><li id="menu-item-2681" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-2681"><a href="https://nkiri.com" class="menu-link"><span class="text-wrap">Home</span></a></li><li id="menu-item-92581" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-92581"><a href="https://dramakey.com/" class="menu-link"><span class="text-wrap">Chinese Drama</span></a></li><li id="menu-item-5528" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5528"><a href="https://nkiri.com/korean-drama-menu/" class="menu-link"><span class="text-wrap">K-Drama</span></a></li><li id="menu-item-14390" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14390"><a href="https://nkiri.com/tv-series-menu/" class="menu-link"><span class="text-wrap">TV Series</span></a></li><li id="menu-item-10227" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children dropdown menu-item-10227"><a href="#" class="menu-link"><span class="text-wrap">Movies<i class="nav-arrow fa fa-angle-down" aria-hidden="true" role="img"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-328" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-328"><a href="https://nkiri.com/category/international/" class="menu-link"><span class="text-wrap">International</span></a></li>	<li id="menu-item-4420" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children dropdown menu-item-4420"><a href="https://nkiri.com/category/asian-movies/" class="menu-link"><span class="text-wrap">Asian Movies<i class="nav-arrow fa fa-angle-right" aria-hidden="true" role="img"></i></span></a>
	<ul class="sub-menu">
		<li id="menu-item-5899" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5899"><a href="https://nkiri.com/category/asian-movies/download-bollywood-movies/" class="menu-link"><span class="text-wrap">Bollywood</span></a></li>		<li id="menu-item-5900" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5900"><a href="https://nkiri.com/category/asian-movies/download-korean-movies/" class="menu-link"><span class="text-wrap">Korean Movies</span></a></li>		<li id="menu-item-5901" class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5901"><a href="https://nkiri.com/category/asian-movies/download-philippine-movies/" class="menu-link"><span class="text-wrap">Philippine Movies</span></a></li>	</ul>
</li></ul>
</li><li id="menu-item-2682" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children dropdown menu-item-2682 nav-no-click"><a href="https://nkiri.com" class="menu-link"><span class="text-wrap">Genre<i class="nav-arrow fa fa-angle-down" aria-hidden="true" role="img"></i></span></a>
<ul class="sub-menu">
	<li id="menu-item-2684" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2684"><a href="https://nkiri.com/tag/action" class="menu-link"><span class="text-wrap">Action</span></a></li>	<li id="menu-item-2685" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2685"><a href="https://nkiri.com/tag/adventure" class="menu-link"><span class="text-wrap">Adventure</span></a></li>	<li id="menu-item-2693" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2693"><a href="https://nkiri.com/tag/animation" class="menu-link"><span class="text-wrap">Animation</span></a></li>	<li id="menu-item-2698" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2698"><a href="https://nkiri.com/tag/biography" class="menu-link"><span class="text-wrap">Biography</span></a></li>	<li id="menu-item-2692" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2692"><a href="https://nkiri.com/tag/comedy" class="menu-link"><span class="text-wrap">Comedy</span></a></li>	<li id="menu-item-2694" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2694"><a href="https://nkiri.com/tag/crime" class="menu-link"><span class="text-wrap">Crime</span></a></li>	<li id="menu-item-2686" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2686"><a href="https://nkiri.com/tag/drama" class="menu-link"><span class="text-wrap">Drama</span></a></li>	<li id="menu-item-4421" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4421"><a href="http://nkiri.com/tag/documentary/" class="menu-link"><span class="text-wrap">Documentary</span></a></li>	<li id="menu-item-2695" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2695"><a href="https://nkiri.com/tag/fantasy" class="menu-link"><span class="text-wrap">Fantasy</span></a></li>	<li id="menu-item-2691" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2691"><a href="https://nkiri.com/tag/family" class="menu-link"><span class="text-wrap">Family</span></a></li>	<li id="menu-item-2689" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2689"><a href="https://nkiri.com/tag/horror" class="menu-link"><span class="text-wrap">Horror</span></a></li>	<li id="menu-item-2697" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2697"><a href="https://nkiri.com/tag/music" class="menu-link"><span class="text-wrap">Music</span></a></li>	<li id="menu-item-2688" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2688"><a href="https://nkiri.com/tag/mystery" class="menu-link"><span class="text-wrap">Mystery</span></a></li>	<li id="menu-item-2687" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2687"><a href="https://nkiri.com/tag/romance" class="menu-link"><span class="text-wrap">Romance</span></a></li>	<li id="menu-item-2696" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2696"><a href="https://nkiri.com/tag/sci-fi/" class="menu-link"><span class="text-wrap">Sci-Fi</span></a></li>	<li id="menu-item-4422" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4422"><a href="http://nkiri.com/tag/sport/" class="menu-link"><span class="text-wrap">Sports</span></a></li>	<li id="menu-item-2690" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2690"><a href="https://nkiri.com/tag/thriller" class="menu-link"><span class="text-wrap">Thriller</span></a></li>	<li id="menu-item-2683" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2683"><a href="https://nkiri.com/tag/war/" class="menu-link"><span class="text-wrap">War</span></a></li></ul>
</li><li id="menu-item-3689" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3689"><a href="https://nkiri.com/how-to-download/" class="menu-link"><span class="text-wrap">How to download</span></a></li><li class="search-toggle-li" ><a href="https://nkiri.com/#" class="site-search-toggle search-dropdown-toggle"><span class="screen-reader-text">Toggle website search</span><i class=" icon-magnifier" aria-hidden="true" role="img"></i></a></li></ul>
<div id="searchform-dropdown" class="header-searchform-wrap clr" >
	<form data-min-no-for-search=1 data-result-box-max-height=400 data-form-id=51 class="is-search-form is-form-style is-form-style-2 is-form-id-51 is-ajax-search" action="https://nkiri.com/" method="get" role="search" ><label for="is-search-input-51"><span class="is-screen-reader-text">Search for:</span><input  type="search" id="is-search-input-51" name="s" value="" class="is-search-input" placeholder="Search Here" autocomplete=off /><span class="is-loader-image" style="display: none;background-image:url(https://nkiri.com/wp-content/plugins/add-search-to-menu/public/images/spinner.gif);" ></span></label><input type="hidden" name="post_type" value="post" /></form></div><!-- #searchform-dropdown -->

			</nav><!-- #site-navigation -->

			
			
					</div><!-- #site-navigation-wrap -->
			
		
	
				
	
	<div class="oceanwp-mobile-menu-icon clr mobile-right">

		
		
		
		<a href="https://nkiri.com/#mobile-menu-toggle" class="mobile-menu"  aria-label="Mobile Menu">
							<i class="fa fa-bars" aria-hidden="true"></i>
								<span class="oceanwp-text">Menu</span>
				<span class="oceanwp-close-text">Close</span>
						</a>

		
		
		
	</div><!-- #oceanwp-mobile-menu-navbar -->

	

			</div><!-- #site-header-inner -->

			
<div id="mobile-dropdown" class="clr" >

	<nav class="clr has-social" itemscope="itemscope" itemtype="https://schema.org/SiteNavigationElement">

		<ul id="menu-main-menu-1" class="menu"><li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-2681"><a href="https://nkiri.com">Home</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-92581"><a href="https://dramakey.com/">Chinese Drama</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-5528"><a href="https://nkiri.com/korean-drama-menu/">K-Drama</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-14390"><a href="https://nkiri.com/tv-series-menu/">TV Series</a></li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10227"><a href="#">Movies</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-328"><a href="https://nkiri.com/category/international/">International</a></li>
	<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-has-children menu-item-4420"><a href="https://nkiri.com/category/asian-movies/">Asian Movies</a>
	<ul class="sub-menu">
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5899"><a href="https://nkiri.com/category/asian-movies/download-bollywood-movies/">Bollywood</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5900"><a href="https://nkiri.com/category/asian-movies/download-korean-movies/">Korean Movies</a></li>
		<li class="menu-item menu-item-type-taxonomy menu-item-object-category menu-item-5901"><a href="https://nkiri.com/category/asian-movies/download-philippine-movies/">Philippine Movies</a></li>
	</ul>
</li>
</ul>
</li>
<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-has-children menu-item-2682"><a href="https://nkiri.com">Genre</a>
<ul class="sub-menu">
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2684"><a href="https://nkiri.com/tag/action">Action</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2685"><a href="https://nkiri.com/tag/adventure">Adventure</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2693"><a href="https://nkiri.com/tag/animation">Animation</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2698"><a href="https://nkiri.com/tag/biography">Biography</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2692"><a href="https://nkiri.com/tag/comedy">Comedy</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2694"><a href="https://nkiri.com/tag/crime">Crime</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2686"><a href="https://nkiri.com/tag/drama">Drama</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4421"><a href="http://nkiri.com/tag/documentary/">Documentary</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2695"><a href="https://nkiri.com/tag/fantasy">Fantasy</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2691"><a href="https://nkiri.com/tag/family">Family</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2689"><a href="https://nkiri.com/tag/horror">Horror</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2697"><a href="https://nkiri.com/tag/music">Music</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2688"><a href="https://nkiri.com/tag/mystery">Mystery</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2687"><a href="https://nkiri.com/tag/romance">Romance</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2696"><a href="https://nkiri.com/tag/sci-fi/">Sci-Fi</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-4422"><a href="http://nkiri.com/tag/sport/">Sports</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2690"><a href="https://nkiri.com/tag/thriller">Thriller</a></li>
	<li class="menu-item menu-item-type-custom menu-item-object-custom menu-item-2683"><a href="https://nkiri.com/tag/war/">War</a></li>
</ul>
</li>
<li class="menu-item menu-item-type-post_type menu-item-object-page menu-item-3689"><a href="https://nkiri.com/how-to-download/">How to download</a></li>
<li class="search-toggle-li" ><a href="https://nkiri.com/#" class="site-search-toggle search-dropdown-toggle"><span class="screen-reader-text">Toggle website search</span><i class=" icon-magnifier" aria-hidden="true" role="img"></i></a></li></ul>
<div id="mobile-menu-search" class="clr">
	<form aria-label="Search this website" method="get" action="https://nkiri.com/" class="mobile-searchform">
		<input aria-label="Insert search query" value="" class="field" id="ocean-mobile-search-2" type="search" name="s" autocomplete="off" placeholder="Search" />
		<button aria-label="Submit search" type="submit" class="searchform-submit">
			<i class=" icon-magnifier" aria-hidden="true" role="img"></i>		</button>
					</form>
</div><!-- .mobile-menu-search -->

	</nav>

</div>

			
			
		
		
</header><!-- #site-header -->


			
			<main id="main" class="site-main clr"  role="main">

				
						
						<div id="content-wrap" class="container clr">

							
							<div id="primary" class="content-area clr">

								
								<div id="content" class="clr site-content">

									
									<article class="entry clr">

										
												<div class="error404-content clr">
													
													<h2 class="error-title">This page could not be found!</h2>
													<p class="error-text">We are sorry. But the page you are looking for is not available.<br />Perhaps you can try a new search.</p>
													<form data-min-no-for-search=1 data-result-box-max-height=400 data-form-id=51 class="is-search-form is-form-style is-form-style-2 is-form-id-51 is-ajax-search" action="https://nkiri.com/" method="get" role="search" ><label for="is-search-input-51"><span class="is-screen-reader-text">Search for:</span><input  type="search" id="is-search-input-51" name="s" value="" class="is-search-input" placeholder="Search Here" autocomplete=off /><span class="is-loader-image" style="display: none;background-image:url(https://nkiri.com/wp-content/plugins/add-search-to-menu/public/images/spinner.gif);" ></span></label><input type="hidden" name="post_type" value="post" /></form>													<a class="error-btn button" href="https://nkiri.com/">Back To Homepage</a>

												</div><!-- .error404-content -->

												
									</article><!-- .entry -->

									
								</div><!-- #content -->

								
							</div><!-- #primary -->

							
						</div><!-- #content-wrap -->

						

	</main><!-- #main -->

	
	
	
		
<footer id="footer" class="site-footer" itemscope="itemscope" itemtype="https://schema.org/WPFooter" role="contentinfo">

	
	<div id="footer-inner" class="clr">

		

<div id="footer-widgets" class="oceanwp-row clr">

	
	<div class="footer-widgets-inner container">

					<div class="footer-box span_1_of_1 col col-1">
							</div><!-- .footer-one-box -->

			
			
			
			
	</div><!-- .container -->

	
</div><!-- #footer-widgets -->


	</div><!-- #footer-inner -->

	
</footer><!-- #footer -->

	
	
</div><!-- #wrap -->


</div><!-- #outer-wrap -->



<a aria-label="Scroll to the top of the page" href="#" id="scroll-top" class="scroll-top-right"><i class=" fa fa-angle-up" aria-hidden="true" role="img"></i></a>




			<script type='text/javascript'>
				const lazyloadRunObserver = () => {
					const lazyloadBackgrounds = document.querySelectorAll( `.e-con.e-parent:not(.e-lazyloaded)` );
					const lazyloadBackgroundObserver = new IntersectionObserver( ( entries ) => {
						entries.forEach( ( entry ) => {
							if ( entry.isIntersecting ) {
								let lazyloadBackground = entry.target;
								if( lazyloadBackground ) {
									lazyloadBackground.classList.add( 'e-lazyloaded' );
								}
								lazyloadBackgroundObserver.unobserve( entry.target );
							}
						});
					}, { rootMargin: '200px 0px 200px 0px' } );
					lazyloadBackgrounds.forEach( ( lazyloadBackground ) => {
						lazyloadBackgroundObserver.observe( lazyloadBackground );
					} );
				};
				const events = [
					'DOMContentLoaded',
					'elementor/lazyload/observe',
				];
				events.forEach( ( event ) => {
					document.addEventListener( event, lazyloadRunObserver );
				} );
			</script>
			<link rel='stylesheet' id='ivory-ajax-search-styles-css' href='https://nkiri.com/wp-content/plugins/add-search-to-menu/public/css/ivory-ajax-search.min.css?ver=5.5.7' media='all' />
<style id='core-block-supports-inline-css'>
/**
 * Core styles: block-supports
 */

</style>
<script src="https://nkiri.com/wp-includes/js/imagesloaded.min.js?ver=5.0.0" id="imagesloaded-js"></script>
<script id="oceanwp-main-js-extra">
var oceanwpLocalize = {"nonce":"e15a52a622","isRTL":"","menuSearchStyle":"drop_down","mobileMenuSearchStyle":"disabled","sidrSource":null,"sidrDisplace":"1","sidrSide":"left","sidrDropdownTarget":"link","verticalHeaderTarget":"link","customScrollOffset":"0","customSelects":".woocommerce-ordering .orderby, #dropdown_product_cat, .widget_categories select, .widget_archive select, .single-product .variations_form .variations select"};
</script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/theme.min.js?ver=3.6.0" id="oceanwp-main-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/drop-down-mobile-menu.min.js?ver=3.6.0" id="oceanwp-drop-down-mobile-menu-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/drop-down-search.min.js?ver=3.6.0" id="oceanwp-drop-down-search-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/vendors/magnific-popup.min.js?ver=3.6.0" id="ow-magnific-popup-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/ow-lightbox.min.js?ver=3.6.0" id="oceanwp-lightbox-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/vendors/flickity.pkgd.min.js?ver=3.6.0" id="ow-flickity-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/ow-slider.min.js?ver=3.6.0" id="oceanwp-slider-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/scroll-effect.min.js?ver=3.6.0" id="oceanwp-scroll-effect-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/scroll-top.min.js?ver=3.6.0" id="oceanwp-scroll-top-js"></script>
<script src="https://nkiri.com/wp-content/themes/oceanwp/assets/js/select.min.js?ver=3.6.0" id="oceanwp-select-js"></script>
<script id="eael-general-js-extra">
var localize = {"ajaxurl":"https:\/\/nkiri.com\/wp-admin\/admin-ajax.php","nonce":"2960e7f8dc","i18n":{"added":"Added ","compare":"Compare","loading":"Loading..."},"eael_translate_text":{"required_text":"is a required field","invalid_text":"Invalid","billing_text":"Billing","shipping_text":"Shipping","fg_mfp_counter_text":"of"},"page_permalink":"","cart_redirectition":"","cart_page_url":"","el_breakpoints":{"mobile":{"label":"Mobile Portrait","value":767,"default_value":767,"direction":"max","is_enabled":true},"mobile_extra":{"label":"Mobile Landscape","value":880,"default_value":880,"direction":"max","is_enabled":false},"tablet":{"label":"Tablet Portrait","value":1024,"default_value":1024,"direction":"max","is_enabled":true},"tablet_extra":{"label":"Tablet Landscape","value":1200,"default_value":1200,"direction":"max","is_enabled":false},"laptop":{"label":"Laptop","value":1366,"default_value":1366,"direction":"max","is_enabled":false},"widescreen":{"label":"Widescreen","value":2400,"default_value":2400,"direction":"min","is_enabled":false}}};
</script>
<script src="https://nkiri.com/wp-content/plugins/essential-addons-for-elementor-lite/assets/front-end/js/view/general.min.js?ver=6.0.6" id="eael-general-js"></script>
<script id="ivory-search-scripts-js-extra">
var IvorySearchVars = {"is_analytics_enabled":"1"};
</script>
<script src="https://nkiri.com/wp-content/plugins/add-search-to-menu/public/js/ivory-search.min.js?ver=5.5.7" id="ivory-search-scripts-js"></script>
<script id="ivory-ajax-search-scripts-js-extra">
var IvoryAjaxVars = {"ajaxurl":"https:\/\/nkiri.com\/wp-admin\/admin-ajax.php","ajax_nonce":"7e1270d293"};
</script>
<script src="https://nkiri.com/wp-content/plugins/add-search-to-menu/public/js/ivory-ajax-search.min.js?ver=5.5.7" id="ivory-ajax-search-scripts-js"></script>
<script>( function () {
	window.advanced_ads_ready_queue = window.advanced_ads_ready_queue || [];

	// replace native push method with our advanced_ads_ready function; do this early to prevent race condition between pushing and the loop.
	advanced_ads_ready_queue.push = window.advanced_ads_ready;

	// handle all callbacks that have been added to the queue previously.
	for ( var i = 0, length = advanced_ads_ready_queue.length; i < length; i ++ ) {
		advanced_ads_ready( advanced_ads_ready_queue[i] );
	}
} )();
</script></body>
</html>


<!-- Page cached by LiteSpeed Cache 6.5.1 on 2024-10-08 11:21:14 -->